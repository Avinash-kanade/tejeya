# AI Tourist Guide (Streamlit + ChromaDB + Gemini)

A multilingual (English / Marathi / Hindi) RAG tourist guide for Maharashtra.

## Setup

```bash
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env              # Windows: copy .env.example .env
# edit .env and add your GEMINI_API_KEY
streamlit run app.py
```

The first run downloads the `all-MiniLM-L6-v2` embedding model (~90 MB) and indexes
the files in `data/`. The vector store is saved in `chroma_db/` and reused later.

## Structure

| File | Purpose |
|------|---------|
| `app.py` | Streamlit chat UI and sidebar |
| `rag_engine.py` | Chunking, ChromaDB indexing/retrieval, Gemini calls |
| `data/` | Default tourism knowledge base (.txt, .pdf, .json all supported) |
| `.env.example` | Template for your API key and options |

## How it works

1. Documents are split with a recursive splitter (500 chars, 50 overlap).
2. Chunks are embedded with `sentence-transformers/all-MiniLM-L6-v2` and stored in ChromaDB (cosine).
3. Gemini detects the user's language and writes a short English search query
   (the embedding model is English-centric, so this keeps Marathi/Hindi retrieval accurate).
4. The top 3 chunks are retrieved and Gemini answers **only** from them, in the user's language.

## Notes

- `gemini-1.5-flash` is the default model (set `GEMINI_MODEL` to change it). Google has
  retired the 1.5 models, so the app automatically falls back to `gemini-2.0-flash`
  and then `gemini-2.5-flash` if the primary model is not available.
- Prices and timings in `data/` are indicative sample data. Replace or extend them with
  verified information, or upload your own files from the sidebar.
