"""Streamlit frontend for the AI Tourist Guide.

Run with:  streamlit run app.py
"""

from __future__ import annotations

import streamlit as st

from rag_engine import (
    DEFAULT_TOP_K,
    SUPPORTED_EXTENSIONS,
    GeminiError,
    RAGError,
    TouristGuide,
    TourismRAG,
    resolve_api_key,
)

st.set_page_config(
    page_title="AI Tourist Guide - Maharashtra",
    page_icon="🧭",
    layout="wide",
)

WELCOME_MESSAGE = (
    "Namaste! 🙏 / नमस्कार! / नमस्ते!\n\n"
    "I'm your local tourist guide for Maharashtra. Ask me about places, visiting "
    "hours, ticket prices, history and local food - in **English, मराठी or हिंदी**."
)

SAMPLE_QUESTIONS = [
    ("🕒 Visiting hours", "What are the visiting hours of Shaniwar Wada?"),
    ("🏛️ Historical significance", "What is the historical significance of Sinhagad Fort?"),
    ("🍛 Best local food nearby", "What is the best local food near Aga Khan Palace?"),
    ("🎟️ टिकट की कीमत (हिंदी)", "अजंता गुफाओं का टिकट कितने का है?"),
    ("📜 इतिहास (मराठी)", "शनिवार वाड्याचा इतिहास सांगा."),
]


# --------------------------------------------------------------------------- #
# Cached resources and session state
# --------------------------------------------------------------------------- #
@st.cache_resource(show_spinner="Loading embedding model and knowledge base...")
def load_rag() -> TourismRAG:
    rag = TourismRAG()
    rag.ensure_indexed()
    return rag


def init_state() -> None:
    st.session_state.setdefault(
        "messages", [{"role": "assistant", "content": WELCOME_MESSAGE, "sources": []}]
    )
    st.session_state.setdefault("pending_question", None)
    st.session_state.setdefault("uploader_key", 0)
    st.session_state.setdefault("flash", None)
    st.session_state.setdefault("guide", None)
    st.session_state.setdefault("guide_key", None)


def get_guide(rag: TourismRAG, api_key: str) -> TouristGuide:
    """Reuse one TouristGuide per API key so the working model stays cached."""
    if st.session_state.guide is None or st.session_state.guide_key != api_key:
        st.session_state.guide = TouristGuide(rag, api_key=api_key)
        st.session_state.guide_key = api_key
    return st.session_state.guide


def chat_history_for_model() -> list[dict[str, str]]:
    """Conversation turns (without the welcome message) for follow-up context."""
    return [
        {"role": m["role"], "content": m["content"]}
        for m in st.session_state.messages[1:]
    ]


# --------------------------------------------------------------------------- #
# Sidebar
# --------------------------------------------------------------------------- #
def render_sidebar(rag: TourismRAG) -> str | None:
    with st.sidebar:
        st.title("🧭 Tourist Guide")

        st.subheader("🔑 Gemini API key")
        typed_key = st.text_input(
            "API key",
            type="password",
            placeholder="Paste key (or leave empty to use .env)",
            label_visibility="collapsed",
        )
        api_key = resolve_api_key(typed_key)
        if typed_key.strip():
            st.caption("Using the key you entered (kept only in this session).")
        elif api_key:
            st.caption("Using GEMINI_API_KEY from your .env file.")
        else:
            st.warning("No API key yet. Enter one above or add it to .env.")

        st.divider()
        st.subheader("📚 Knowledge base")
        st.caption(f"{rag.count()} chunks from {len(rag.list_sources())} documents indexed")

        flash = st.session_state.flash
        if flash:
            kind, text = flash
            getattr(st, kind)(text)
            st.session_state.flash = None

        uploads = st.file_uploader(
            "Add your own attraction data",
            type=[ext.lstrip(".") for ext in SUPPORTED_EXTENSIONS],
            accept_multiple_files=True,
            key=f"uploader_{st.session_state.uploader_key}",
        )
        if st.button("➕ Add to knowledge base", disabled=not uploads, use_container_width=True):
            added, errors = [], []
            with st.spinner("Indexing documents..."):
                for f in uploads:
                    try:
                        n = rag.add_file(f.name, f.getvalue())
                        added.append(f"{f.name} ({n} chunks)")
                    except RAGError as exc:
                        errors.append(str(exc))
            if errors:
                st.session_state.flash = ("error", " ".join(errors))
            else:
                st.session_state.flash = ("success", "Added: " + ", ".join(added))
            st.session_state.uploader_key += 1
            st.rerun()

        if st.button("🔄 Reset / re-index database", use_container_width=True):
            with st.spinner("Re-indexing..."):
                results = rag.reset()
            st.session_state.flash = (
                "success",
                f"Database reset. Re-indexed {len(results)} default documents "
                "(uploaded files were removed).",
            )
            st.rerun()

        st.divider()
        st.subheader("💡 Try asking")
        for label, question in SAMPLE_QUESTIONS:
            if st.button(label, key=f"sample_{label}", use_container_width=True):
                st.session_state.pending_question = question
                st.rerun()

        st.divider()
        if st.button("🧹 Clear chat", use_container_width=True):
            st.session_state.messages = [
                {"role": "assistant", "content": WELCOME_MESSAGE, "sources": []}
            ]
            st.rerun()

    return api_key


# --------------------------------------------------------------------------- #
# Chat
# --------------------------------------------------------------------------- #
def render_sources(sources: list[dict[str, str]]) -> None:
    if not sources:
        return
    with st.expander(f"📖 Sources used ({len(sources)})"):
        for i, src in enumerate(sources, 1):
            st.markdown(f"**{i}. {src['source']}**")
            st.caption(src["text"])


def main() -> None:
    init_state()
    rag = load_rag()
    api_key = render_sidebar(rag)

    st.title("🧭 AI Tourist Guide")
    st.caption(
        f"Answers come from the knowledge base (top {DEFAULT_TOP_K} matches) • "
        "English • मराठी • हिंदी"
    )

    for msg in st.session_state.messages:
        with st.chat_message(msg["role"], avatar="🧭" if msg["role"] == "assistant" else None):
            st.markdown(msg["content"])
            render_sources(msg.get("sources", []))

    question = st.chat_input("Ask about a place, timings, tickets, history or food...")
    if not question and st.session_state.pending_question:
        question = st.session_state.pending_question
    st.session_state.pending_question = None

    if not question:
        return

    with st.chat_message("user"):
        st.markdown(question)

    if not api_key:
        st.error("Please enter your Gemini API key in the sidebar or add it to your .env file.")
        return

    with st.chat_message("assistant", avatar="🧭"):
        with st.spinner("Consulting local knowledge..."):
            try:
                guide = get_guide(rag, api_key)
                result = guide.ask(question, history=chat_history_for_model())
            except GeminiError as exc:
                st.error(str(exc))
                return
            except RAGError as exc:
                st.error(str(exc))
                return
            except Exception as exc:  # noqa: BLE001 - never crash the UI
                st.error(f"Something went wrong: {exc}")
                return

        st.markdown(result.answer)
        sources = [{"source": c.source, "text": c.text} for c in result.chunks]
        render_sources(sources)

    st.session_state.messages.append({"role": "user", "content": question, "sources": []})
    st.session_state.messages.append(
        {"role": "assistant", "content": result.answer, "sources": sources}
    )


main()
