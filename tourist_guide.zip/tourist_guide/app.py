"""Streamlit frontend for the AI Tourist Guide (RAG + Gemini)."""
from __future__ import annotations

import os

import streamlit as st
from dotenv import load_dotenv

from rag_engine import LANGUAGE_NAMES, RAGError, TourismRAG, generate_answer

load_dotenv()

CHROMA_DIR = os.getenv("CHROMA_DIR", "./chroma_db")
DATA_DIR = os.getenv("DATA_DIR", "./data")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")

SAMPLE_QUESTIONS = {
    "🕒 Visiting hours": "What are the visiting hours and ticket prices of Shaniwar Wada?",
    "🏛️ Historical significance": "What is the historical significance of Sinhagad Fort?",
    "🍛 Best local food nearby": "What is the best local food near the Gateway of India?",
    "🇮🇳 हिंदी में पूछें": "आगा खान पैलेस का इतिहास क्या है?",
    "🚩 मराठीत विचारा": "एलिफंटा लेणी कधी बंद असतात आणि तिकीट किती आहे?",
}

st.set_page_config(page_title="AI Tourist Guide", page_icon="🧭", layout="wide")


@st.cache_resource(show_spinner="Loading embedding model and knowledge base…")
def get_engine() -> TourismRAG:
    engine = TourismRAG(persist_dir=CHROMA_DIR, data_dir=DATA_DIR)
    engine.ensure_indexed()
    return engine


engine = get_engine()

if "messages" not in st.session_state:
    st.session_state.messages = []
if "pending_question" not in st.session_state:
    st.session_state.pending_question = None
if "processed_uploads" not in st.session_state:
    st.session_state.processed_uploads = set()

# ------------------------------------------------------------------ sidebar
with st.sidebar:
    st.title("🧭 Yatri Mitra")
    st.caption("Your multilingual AI tourist guide")

    st.subheader("🔑 Gemini API Key")
    user_key = st.text_input("API Key", type="password", placeholder="Uses .env if empty")
    api_key = user_key.strip() or os.getenv("GOOGLE_API_KEY", "")
    if api_key:
        st.success("Key loaded" + (" (from .env)" if not user_key else ""))
    else:
        st.warning("No API key found.")

    k = st.slider("Chunks to retrieve", min_value=2, max_value=3, value=3)

    st.subheader("📄 Add tourist data")
    uploads = st.file_uploader(
        "Upload .txt, .pdf or .json", type=["txt", "pdf", "json"], accept_multiple_files=True
    )
    if uploads:
        for f in uploads:
            key = (f.name, f.size)
            if key in st.session_state.processed_uploads:
                continue
            try:
                with st.spinner(f"Indexing {f.name}…"):
                    n = engine.add_document(f.name, f.getvalue())
                st.session_state.processed_uploads.add(key)
                st.success(f"{f.name}: {n} chunks added")
            except RAGError as e:
                st.error(str(e))

    st.subheader("🗄️ Knowledge base")
    st.metric("Indexed chunks", engine.count())
    with st.expander("Sources"):
        for s in engine.list_sources() or ["(empty)"]:
            st.write(f"• {s}")
    if st.button("🔄 Reset & re-index", use_container_width=True):
        with st.spinner("Rebuilding index from data folder…"):
            result = engine.reset(reindex=True)
        st.session_state.processed_uploads = set()
        st.success(f"Re-indexed {len(result)} file(s), {engine.count()} chunks.")
        st.rerun()

    st.subheader("💡 Sample questions")
    for label, q in SAMPLE_QUESTIONS.items():
        if st.button(label, use_container_width=True):
            st.session_state.pending_question = q

    if st.button("🧹 Clear chat", use_container_width=True):
        st.session_state.messages = []
        st.rerun()

# ------------------------------------------------------------------ chat
st.title("🧭 AI Tourist Guide")
st.caption("Ask in English, हिंदी or मराठी — I answer only from the trusted guide data.")

for msg in st.session_state.messages:
    with st.chat_message(msg["role"], avatar="🧳" if msg["role"] == "user" else "🧭"):
        st.markdown(msg["content"])
        if msg.get("sources"):
            with st.expander("Sources used"):
                for src in msg["sources"]:
                    st.markdown(f"**{src['source']}** (similarity {1 - src['distance']:.2f})")
                    st.caption(src["text"])

typed = st.chat_input("Ask about places, timings, tickets, history or food…")
question = typed or st.session_state.pending_question
st.session_state.pending_question = None

if question:
    history = list(st.session_state.messages)
    st.session_state.messages.append({"role": "user", "content": question})
    with st.chat_message("user", avatar="🧳"):
        st.markdown(question)

    with st.chat_message("assistant", avatar="🧭"):
        with st.spinner("Looking through the guidebook…"):
            try:
                chunks = engine.retrieve(question, k=k)
                answer, lang = generate_answer(
                    question, chunks, api_key=api_key, model_name=GEMINI_MODEL, history=history
                )
                st.markdown(answer)
                st.caption(f"Language: {LANGUAGE_NAMES[lang]}")
                sources = [c.__dict__ for c in chunks]
                if sources:
                    with st.expander("Sources used"):
                        for src in sources:
                            st.markdown(f"**{src['source']}** (similarity {1 - src['distance']:.2f})")
                            st.caption(src["text"])
                st.session_state.messages.append(
                    {"role": "assistant", "content": answer, "sources": sources}
                )
            except RAGError as e:
                st.error(str(e))
            except Exception as e:  # noqa: BLE001
                st.error(f"Unexpected error: {e}")
