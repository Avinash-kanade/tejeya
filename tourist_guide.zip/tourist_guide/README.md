# AI Tourist Guide (Streamlit + ChromaDB + Gemini)

## Setup
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env    # add your GOOGLE_API_KEY
streamlit run app.py
```
On first run, files in `data/` are chunked (500/50), embedded with all-MiniLM-L6-v2 and stored in `chroma_db/`.

## Files
- `rag_engine.py` – loading (.txt/.pdf/.json), chunking, ChromaDB indexing, retrieval, language detection, Gemini call with error handling.
- `app.py` – Streamlit chat UI with sidebar (API key, uploads, reset/re-index, sample questions).
- `data/` – sample Pune & Mumbai knowledge base. Add your own files here, then click "Reset & re-index".

Note: if `gemini-1.5-flash` is unavailable for your key, set `GEMINI_MODEL=gemini-2.0-flash` in `.env`.
