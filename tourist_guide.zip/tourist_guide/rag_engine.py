"""RAG engine for the AI Tourist Guide.

Responsibilities:
  * Load documents (.txt, .pdf, .json) from disk or uploaded bytes.
  * Chunk with recursive character splitting (size 500, overlap 50).
  * Embed with sentence-transformers/all-MiniLM-L6-v2 and store in persistent ChromaDB.
  * Retrieve the top-k chunks for a query.
  * Detect language (English / Hindi / Marathi) and call Gemini with a grounded prompt.
"""
from __future__ import annotations

import hashlib
import io
import json
import logging
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import chromadb
from chromadb.utils import embedding_functions
from langchain_text_splitters import RecursiveCharacterTextSplitter
from pypdf import PdfReader

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

EMBED_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
COLLECTION_NAME = "tourism_kb"
CHUNK_SIZE = 500
CHUNK_OVERLAP = 50
SUPPORTED_EXT = {".txt", ".pdf", ".json"}

LANGUAGE_NAMES = {"en": "English", "hi": "Hindi", "mr": "Marathi"}

# Words that are distinctive to Marathi vs Hindi (both written in Devanagari).
_MARATHI_MARKERS = {
    "आहे", "आहेत", "काय", "कुठे", "किती", "मला", "तुम्ही", "आणि", "नाही", "कसे", "कधी",
    "वेळ", "जवळ", "खाण्याचे", "ठिकाण", "माहिती", "सांगा", "च्या", "चे", "ची", "होते", "येथे",
}
_HINDI_MARKERS = {
    "है", "हैं", "क्या", "कहाँ", "कहां", "कितना", "कितने", "मुझे", "आप", "और", "नहीं", "कैसे",
    "कब", "समय", "पास", "खाना", "जगह", "बताइए", "बताओ", "का", "की", "के", "था", "यहाँ",
}

SYSTEM_PROMPT = """You are "Yatri Mitra", an expert, polite, warm and culturally aware local tourist guide.

STRICT RULES:
1. Answer ONLY using the facts in the CONTEXT section. Never invent timings, prices, dates or names.
2. If the context does not contain the answer, say so politely (e.g. "I'm sorry, I don't have that
   information in my guide right now") and suggest what the traveller could check locally.
3. Reply ENTIRELY in {language}. If {language} is Hindi or Marathi, write in Devanagari script.
4. Be friendly and concise. Use short paragraphs or bullet points for hours, prices and food tips.
5. Show cultural respect (dress codes, customs) only when supported by the context.
"""


class RAGError(Exception):
    """Raised for user-facing errors in the RAG pipeline."""


@dataclass
class RetrievedChunk:
    text: str
    source: str
    distance: float


# --------------------------------------------------------------------------- loading
def _json_to_text(data) -> str:
    """Flatten arbitrary JSON into readable 'key: value' lines."""
    lines: list[str] = []

    def walk(node, prefix: str = ""):
        if isinstance(node, dict):
            for k, v in node.items():
                label = str(k).replace("_", " ").capitalize()
                if isinstance(v, (dict, list)):
                    lines.append(f"{prefix}{label}:")
                    walk(v, prefix + "  ")
                else:
                    lines.append(f"{prefix}{label}: {v}")
        elif isinstance(node, list):
            for item in node:
                walk(item, prefix)
                lines.append("")
        else:
            lines.append(f"{prefix}{node}")

    walk(data)
    return "\n".join(lines).strip()


def extract_text(filename: str, content: bytes) -> str:
    ext = Path(filename).suffix.lower()
    if ext not in SUPPORTED_EXT:
        raise RAGError(f"Unsupported file type '{ext}'. Use .txt, .pdf or .json.")
    try:
        if ext == ".txt":
            return content.decode("utf-8", errors="ignore")
        if ext == ".pdf":
            reader = PdfReader(io.BytesIO(content))
            return "\n".join((page.extract_text() or "") for page in reader.pages)
        return _json_to_text(json.loads(content.decode("utf-8")))
    except json.JSONDecodeError as exc:
        raise RAGError(f"Invalid JSON in {filename}: {exc}") from exc
    except RAGError:
        raise
    except Exception as exc:  # noqa: BLE001
        raise RAGError(f"Could not read {filename}: {exc}") from exc


# --------------------------------------------------------------------------- engine
class TourismRAG:
    def __init__(self, persist_dir: str = "./chroma_db", data_dir: str = "./data"):
        self.persist_dir = persist_dir
        self.data_dir = Path(data_dir)
        self.splitter = RecursiveCharacterTextSplitter(
            chunk_size=CHUNK_SIZE,
            chunk_overlap=CHUNK_OVERLAP,
            separators=["\n\n", "\n", "। ", ". ", " ", ""],
        )
        self.embedding_fn = embedding_functions.SentenceTransformerEmbeddingFunction(model_name=EMBED_MODEL)
        self.client = chromadb.PersistentClient(path=persist_dir)
        self.collection = self._get_collection()

    def _get_collection(self):
        return self.client.get_or_create_collection(
            name=COLLECTION_NAME,
            embedding_function=self.embedding_fn,
            metadata={"hnsw:space": "cosine"},
        )

    # ---- indexing
    def count(self) -> int:
        return self.collection.count()

    def list_sources(self) -> list[str]:
        if self.count() == 0:
            return []
        metas = self.collection.get(include=["metadatas"])["metadatas"] or []
        return sorted({m.get("source", "unknown") for m in metas})

    def add_document(self, filename: str, content: bytes) -> int:
        """Chunk + embed a document. Idempotent: re-adding the same file replaces its chunks."""
        text = extract_text(filename, content).strip()
        if not text:
            raise RAGError(f"No readable text found in {filename}.")
        chunks = [c.strip() for c in self.splitter.split_text(text) if c.strip()]
        self.collection.delete(where={"source": filename})
        ids = [hashlib.md5(f"{filename}:{i}:{c}".encode()).hexdigest() for i, c in enumerate(chunks)]
        self.collection.add(
            ids=ids,
            documents=chunks,
            metadatas=[{"source": filename, "chunk": i} for i in range(len(chunks))],
        )
        logger.info("Indexed %s -> %d chunks", filename, len(chunks))
        return len(chunks)

    def index_folder(self, folder: Path | None = None) -> dict[str, int]:
        folder = folder or self.data_dir
        results: dict[str, int] = {}
        if not folder.exists():
            logger.warning("Data folder %s does not exist", folder)
            return results
        for path in sorted(folder.iterdir()):
            if path.suffix.lower() in SUPPORTED_EXT and path.is_file():
                try:
                    results[path.name] = self.add_document(path.name, path.read_bytes())
                except RAGError as exc:
                    logger.error("%s", exc)
        return results

    def ensure_indexed(self) -> None:
        if self.count() == 0:
            self.index_folder()

    def reset(self, reindex: bool = True) -> dict[str, int]:
        self.client.delete_collection(COLLECTION_NAME)
        self.collection = self._get_collection()
        return self.index_folder() if reindex else {}

    # ---- retrieval
    def retrieve(self, query: str, k: int = 3) -> list[RetrievedChunk]:
        if self.count() == 0:
            return []
        res = self.collection.query(
            query_texts=[query],
            n_results=min(k, self.count()),
            include=["documents", "metadatas", "distances"],
        )
        return [
            RetrievedChunk(text=d, source=m.get("source", "unknown"), distance=float(dist))
            for d, m, dist in zip(res["documents"][0], res["metadatas"][0], res["distances"][0])
        ]


# --------------------------------------------------------------------------- language
def detect_language(text: str) -> str:
    """Return 'en', 'hi' or 'mr'."""
    if not re.search(r"[\u0900-\u097F]", text):
        return "en"
    tokens = set(re.findall(r"[\u0900-\u097F]+", text))
    mr = len(tokens & _MARATHI_MARKERS)
    hi = len(tokens & _HINDI_MARKERS)
    if mr != hi:
        return "mr" if mr > hi else "hi"
    try:
        from langdetect import DetectorFactory, detect

        DetectorFactory.seed = 0
        code = detect(text)
        if code in ("mr", "hi"):
            return code
    except Exception:  # noqa: BLE001
        pass
    return "hi"


# --------------------------------------------------------------------------- generation
def _format_context(chunks: Iterable[RetrievedChunk]) -> str:
    return "\n\n".join(f"[Source: {c.source}]\n{c.text}" for c in chunks) or "(no context found)"


def _format_history(history: list[dict], max_turns: int = 6) -> str:
    recent = history[-max_turns:]
    return "\n".join(f"{m['role'].upper()}: {m['content']}" for m in recent)


def generate_answer(
    query: str,
    chunks: list[RetrievedChunk],
    api_key: str,
    model_name: str = "gemini-1.5-flash",
    history: list[dict] | None = None,
) -> tuple[str, str]:
    """Call Gemini with grounded context. Returns (answer, language_code)."""
    if not api_key:
        raise RAGError("Missing Gemini API key. Enter it in the sidebar or set GOOGLE_API_KEY in .env.")

    import google.generativeai as genai
    from google.api_core import exceptions as gexc

    lang = detect_language(query)
    language = LANGUAGE_NAMES[lang]

    prompt = (
        f"CONTEXT:\n{_format_context(chunks)}\n\n"
        f"RECENT CONVERSATION:\n{_format_history(history or []) or '(none)'}\n\n"
        f"TRAVELLER'S QUESTION ({language}):\n{query}\n\n"
        f"Answer in {language} using only the CONTEXT."
    )

    try:
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel(
            model_name=model_name,
            system_instruction=SYSTEM_PROMPT.format(language=language),
            generation_config={"temperature": 0.2, "max_output_tokens": 1024},
        )
        response = model.generate_content(prompt)
        text = (getattr(response, "text", "") or "").strip()
    except gexc.PermissionDenied as exc:
        raise RAGError("Gemini rejected the API key (permission denied). Please check your key.") from exc
    except gexc.Unauthenticated as exc:
        raise RAGError("Invalid Gemini API key.") from exc
    except gexc.ResourceExhausted as exc:
        raise RAGError("Gemini quota or rate limit reached. Please wait a moment and try again.") from exc
    except gexc.NotFound as exc:
        raise RAGError(
            f"Model '{model_name}' is not available for your key. Set GEMINI_MODEL (e.g. gemini-2.0-flash)."
        ) from exc
    except gexc.InvalidArgument as exc:
        raise RAGError(f"Invalid request to Gemini: {exc.message}") from exc
    except gexc.GoogleAPIError as exc:
        raise RAGError(f"Gemini API error: {exc}") from exc
    except ValueError as exc:  # raised by response.text when blocked by safety filters
        raise RAGError("The response was blocked by Gemini's safety filters. Please rephrase.") from exc

    if not text:
        raise RAGError("Gemini returned an empty response. Please try again.")
    return text, lang
